<?php
echo $status;
?>
