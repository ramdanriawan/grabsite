<?php include "header.php"; ?>

<main class="main col-md-7">
  <content class="content">
    <div class="row data">
      <!-- Text Berita Terbaru -->
      <div class="col-md-6 pull-left">
        <h2 class="terbaru text-capitalize">Berita Terbaru</h2>
      </div>

      <!-- Menu Filter -->
      <div class="col-md-6 pull-right limit">
        <form class="pull-right form-inline" action="index.html" method="post">
            <strong>Limit: </strong><select class="form-control" name="limit">
            <option value="10">10</option>
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="40">40</option>
            <option value="50">50</option>
            <option value="60">60</option>
          </select>
        </form>
      </div>
    </div>

    <!-- list artikel -->
    <artikel class="artikel">
      <div class="row">
        <!--  gambar -->
        <div class="col-md-3 pull-left thumbnail">
          <img src="gambar/ahok.jpg" alt="">
        </div>

        <!--  artikel -->
        <div class="col-md-9 artikle pull-right">
          <!-- judul artikel -->
          <div class="col-md-12">
            <h3><a href="#">Fasilitas Olahraga Pertama Di Taman BMW Mulai Dibangun</a></h3>
          </div>

          <!-- isi artikel -->
          <div class="col-md-12">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </div>

          <!--  data update -->
          <div class="col-md-12">
            <ul class="nav nav-pills dibaca">
              <li><a href="#">Otomotif</a></li>
              <li><a href="#">22:13 WIB</a></li>
              <li><a href="#">Kompas.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </artikel>

    <!-- list artikel -->
    <artikel class="artikel">
      <div class="row">
        <!--  gambar -->
        <div class="col-md-3 pull-left thumbnail">
          <img src="gambar/ahok.jpg" alt="">
        </div>

        <!--  artikel -->
        <div class="col-md-9 artikle pull-right">
          <!-- judul artikel -->
          <div class="col-md-12">
            <h3><a href="#">Fasilitas Olahraga Pertama Di Taman BMW Mulai Dibangun</a></h3>
          </div>

          <!-- isi artikel -->
          <div class="col-md-12">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </div>

          <!--  data update -->
          <div class="col-md-12">
            <ul class="nav nav-pills dibaca">
              <li><a href="#">Otomotif</a></li>
              <li><a href="#">22:13 WIB</a></li>
              <li><a href="#">Kompas.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </artikel>

    <!-- list artikel -->
    <artikel class="artikel">
      <div class="row">
        <!--  gambar -->
        <div class="col-md-3 pull-left thumbnail">
          <img src="gambar/ahok.jpg" alt="">
        </div>

        <!--  artikel -->
        <div class="col-md-9 artikle pull-right">
          <!-- judul artikel -->
          <div class="col-md-12">
            <h3><a href="#">Fasilitas Olahraga Pertama Di Taman BMW Mulai Dibangun</a></h3>
          </div>

          <!-- isi artikel -->
          <div class="col-md-12">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </div>

          <!--  data update -->
          <div class="col-md-12">
            <ul class="nav nav-pills dibaca">
              <li><a href="#">Otomotif</a></li>
              <li><a href="#">22:13 WIB</a></li>
              <li><a href="#">Kompas.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </artikel>

    <!-- list artikel -->
    <artikel class="artikel">
      <div class="row">
        <!--  gambar -->
        <div class="col-md-3 pull-left thumbnail">
          <img src="gambar/ahok.jpg" alt="">
        </div>

        <!--  artikel -->
        <div class="col-md-9 artikle pull-right">
          <!-- judul artikel -->
          <div class="col-md-12">
            <h3><a href="#">Fasilitas Olahraga Pertama Di Taman BMW Mulai Dibangun</a></h3>
          </div>

          <!-- isi artikel -->
          <div class="col-md-12">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </div>

          <!--  data update -->
          <div class="col-md-12">
            <ul class="nav nav-pills dibaca">
              <li><a href="#">Otomotif</a></li>
              <li><a href="#">22:13 WIB</a></li>
              <li><a href="#">Kompas.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </artikel>

    <!-- list artikel -->
    <artikel class="artikel">
      <div class="row">
        <!--  gambar -->
        <div class="col-md-3 pull-left thumbnail">
          <img src="gambar/ahok.jpg" alt="">
        </div>

        <!--  artikel -->
        <div class="col-md-9 artikle pull-right">
          <!-- judul artikel -->
          <div class="col-md-12">
            <h3><a href="#">Fasilitas Olahraga Pertama Di Taman BMW Mulai Dibangun</a></h3>
          </div>

          <!-- isi artikel -->
          <div class="col-md-12">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </div>

          <!--  data update -->
          <div class="col-md-12">
            <ul class="nav nav-pills dibaca">
              <li><a href="#">Otomotif</a></li>
              <li><a href="#">22:13 WIB</a></li>
              <li><a href="#">Kompas.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </artikel>

    <!-- list artikel -->
    <artikel class="artikel">
      <div class="row">
        <!--  gambar -->
        <div class="col-md-3 pull-left thumbnail">
          <img src="gambar/ahok.jpg" alt="">
        </div>

        <!--  artikel -->
        <div class="col-md-9 artikle pull-right">
          <!-- judul artikel -->
          <div class="col-md-12">
            <h3><a href="#">Fasilitas Olahraga Pertama Di Taman BMW Mulai Dibangun</a></h3>
          </div>

          <!-- isi artikel -->
          <div class="col-md-12">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </div>

          <!--  data update -->
          <div class="col-md-12">
            <ul class="nav nav-pills dibaca">
              <li><a href="#">Otomotif</a></li>
              <li><a href="#">22:13 WIB</a></li>
              <li><a href="#">Kompas.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </artikel>

    <!-- list artikel -->
    <artikel class="artikel">
      <div class="row">
        <!--  gambar -->
        <div class="col-md-3 pull-left thumbnail">
          <img src="gambar/ahok.jpg" alt="">
        </div>

        <!--  artikel -->
        <div class="col-md-9 artikle pull-right">
          <!-- judul artikel -->
          <div class="col-md-12">
            <h3><a href="#">Fasilitas Olahraga Pertama Di Taman BMW Mulai Dibangun</a></h3>
          </div>

          <!-- isi artikel -->
          <div class="col-md-12">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </div>

          <!--  data update -->
          <div class="col-md-12">
            <ul class="nav nav-pills dibaca">
              <li><a href="#">Otomotif</a></li>
              <li><a href="#">22:13 WIB</a></li>
              <li><a href="#">Kompas.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </artikel>

    <!-- list artikel -->
    <artikel class="artikel">
      <div class="row">
        <!--  gambar -->
        <div class="col-md-3 pull-left thumbnail">
          <img src="gambar/ahok.jpg" alt="">
        </div>

        <!--  artikel -->
        <div class="col-md-9 artikle pull-right">
          <!-- judul artikel -->
          <div class="col-md-12">
            <h3><a href="#">Fasilitas Olahraga Pertama Di Taman BMW Mulai Dibangun</a></h3>
          </div>

          <!-- isi artikel -->
          <div class="col-md-12">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </div>

          <!--  data update -->
          <div class="col-md-12">
            <ul class="nav nav-pills dibaca">
              <li><a href="#">Otomotif</a></li>
              <li><a href="#">22:13 WIB</a></li>
              <li><a href="#">Kompas.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </artikel>

    <!-- list artikel -->
    <artikel class="artikel">
      <div class="row">
        <!--  gambar -->
        <div class="col-md-3 pull-left thumbnail">
          <img src="gambar/ahok.jpg" alt="">
        </div>

        <!--  artikel -->
        <div class="col-md-9 artikle pull-right">
          <!-- judul artikel -->
          <div class="col-md-12">
            <h3><a href="#">Fasilitas Olahraga Pertama Di Taman BMW Mulai Dibangun</a></h3>
          </div>

          <!-- isi artikel -->
          <div class="col-md-12">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </div>

          <!--  data update -->
          <div class="col-md-12">
            <ul class="nav nav-pills dibaca">
              <li><a href="#">Otomotif</a></li>
              <li><a href="#">22:13 WIB</a></li>
              <li><a href="#">Kompas.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </artikel>

    <!-- list artikel -->
    <artikel class="artikel">
      <div class="row">
        <!--  gambar -->
        <div class="col-md-3 pull-left thumbnail">
          <img src="gambar/ahok.jpg" alt="">
        </div>

        <!--  artikel -->
        <div class="col-md-9 artikle pull-right">
          <!-- judul artikel -->
          <div class="col-md-12">
            <h3><a href="#">Fasilitas Olahraga Pertama Di Taman BMW Mulai Dibangun</a></h3>
          </div>

          <!-- isi artikel -->
          <div class="col-md-12">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </div>

          <!--  data update -->
          <div class="col-md-12">
            <ul class="nav nav-pills dibaca">
              <li><a href="#">Otomotif</a></li>
              <li><a href="#">22:13 WIB</a></li>
              <li><a href="#">Kompas.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </artikel>

    <!-- list artikel -->
    <artikel class="artikel">
      <div class="row">
        <!--  gambar -->
        <div class="col-md-3 pull-left thumbnail">
          <img src="gambar/ahok.jpg" alt="">
        </div>

        <!--  artikel -->
        <div class="col-md-9 artikle pull-right">
          <!-- judul artikel -->
          <div class="col-md-12">
            <h3><a href="#">Fasilitas Olahraga Pertama Di Taman BMW Mulai Dibangun</a></h3>
          </div>

          <!-- isi artikel -->
          <div class="col-md-12">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </div>

          <!--  data update -->
          <div class="col-md-12">
            <ul class="nav nav-pills dibaca">
              <li><a href="#">Otomotif</a></li>
              <li><a href="#">22:13 WIB</a></li>
              <li><a href="#">Kompas.com</a></li>
            </ul>
          </div>
        </div>
      </div>
    </artikel>


  </content>

  <div class="row bungkus">
    <div class="col-md-10 col-md-offset-1">
      <ul class="pagination text-center">
        <li  class="active"><a href="#?page=1">1</a></li>
        <li><a href="#?page=2">2</a></li>
        <li><a href="#?page=3">3</a></li>
        <li><a href="#?page=4">4</a></li>
        <li><a href="#?page=5">5</a></li>
        <li><a href="#?page=6">6</a></li>
        <li><a href="#?page=7">7</a></li>
        <li><a href="#?page=8">8</a></li>
        <li><a href="#?page=9">9</a></li>
        <li><a href="#?page=10">10</a></li>
        <li><a href="#?page=...">...</a></li>
        <li><a href="#?page=...">100</a></li>
      </ul>
    </div>
  </div>
</main>

<?php include "footer.php"; ?>
