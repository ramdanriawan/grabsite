<?php
print "<p>||========================== SCRIPT KOMPAS ==========================||";
require("../kompas/index.php");

print "<p> ||========================== SCRIPT TRIBUNNEWS ==========================||";
require("../tribun/index.php");

print "<p> ||========================== SCRIPT DETIK.COM ==========================||";
require("../detik/index.php");

print "<p> ||========================== SCRIPT VIVA.CO.ID ==========================||";
require("../viva/index.php");

 ?>
